module.exports = ({
name: "eval",
aliases: "eval-aoi",
code: `$onlyForIDs[801241278553653279;776317504053837826;The command is only for $userTag[776317504053837826] and $userTag[801241278553653279], $userTag]
$eval[$message;yes]
$argsCheck[>1;Type something to eval $username!]
`
})