module.exports = ({
name: "set-wikichannel",
code: `$onlyPerms[admin;{title:Missing Permissions}{description:You need the permission of: \`ADMINISTRATOR\` to use this command!}{color:$getRoleColor[$highestRole[$authorID]]}]
$footer[$userTag;$authorAvatar]
$title[Success! <a:tickmark:855857197573210132>]
$description[Now the wikis channel is: <#$mentionedChannels[1]>]
$color[$getRoleColor[$highestRole[$authorID]]]

$argsCheck[1;Mention a channel!]
$onlyIf[$stringStartsWith[$message[1];<#]==true;That is not a channel!]
$setServerVar[wiki_channel;$mentionedChannels[1]]
$addTimestamp
`
})