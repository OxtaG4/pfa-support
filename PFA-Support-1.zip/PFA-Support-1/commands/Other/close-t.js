module.exports = ({
name: "ticket-close",
aliases: "t-close",
code: `$closeTicket[This is not a ticket!]
$dm[$authorID]
Ticket Closed!
`
})