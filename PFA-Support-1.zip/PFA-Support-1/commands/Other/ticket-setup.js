module.exports = ({
name: "ticket-setup",
aliases: "t-setup",
code: `$if[$message==]

$title[Ticket Setup]
$description[To begin, put $getServerVar[prefix]ticket-setup \`Category ID\` \`Language of the Ticket Message\`]
$color[$getRoleColor[$highestRole[$authorID]]]

$else

$setServerVar[ticket_lang;$toUpperCase[$message[2]]]
$setServerVar[ticket_category;$message[1]]
$title[Success! <a:VeriGif:852748359001440256>]
$description[Language of the Ticket has been set to $message[2], and the category ID is $message[1]]
$color[$getRoleColor[$highestRole[$authorID]]]
$footer[$userTag;$authorAvatar]
$addTimestamp

$onlyIf[$message[2]!=Español;You need to put ES or EN!]
$onlyIf[$message[2]!=English;You need to put ES or EN!]
$onlyIf[$message[2]!=Spanish;You need to put ES or EN!]
$onlyIf[$message[2]!=Ingles;You need to put ES or EN!]

$onlyPerms[admin;{title:Missing Permissions}{description:You need the permission of: \`ADMINISTRATOR\` to use this command!}{color:$getRoleColor[$highestRole[$authorID]]}]

$endif
`
})