module.exports = ({
name: "help-other",
aliases: "other",
code: `$if[$getGlobalUserVar[idioma]==Ingles]

$author[PFA Support Help;$userAvatar[$clientID]]
$title[Other Commands:]
$description[:speech_left: **| __WIKIS__ |** :speech_left:
> \`$getServerVar[prefix]set-wikichannel, $getServerVar[prefix]add-wiki\`

:tickets: **| __TICKETS__ |** :tickets:
> \`$getServerVar[prefix]ticket-setup, $getServerVar[prefix]ticket-open, $getServerVar[prefix]ticket-close\`

<a:VeriGif:852748359001440256> **| __VERIFICATION__ |** <a:VeriGif:852748359001440256>
> \`$getServerVar[prefix]verif-setup, $getServerVar[prefix]verif-message\`]
$color[$getRoleColor[$highestRole[$authorID]]]
$footer[Requested by $userTag;$authorAvatar]

$else

$author[PFA Support Help;$userAvatar[$clientID]]
$title[Otros Comandos:]
$description[:speech_left: **| __WIKIS__ |** :speech_left:
> \`$getServerVar[prefix]set-wikichannel, $getServerVar[prefix]add-wiki\`

:tickets: **| __TICKETS__ |** :tickets:
> \`$getServerVar[prefix]ticket-setup, $getServerVar[prefix]ticket-open, $getServerVar[prefix]ticket-close\`

<:check_verif:858031971456253982> **| __VERIFICACION__ |** <:check_verif:858031971456253982>
> \`$getServerVar[prefix]verif-setup, $getServerVar[prefix]verif-message\`]
$color[$getRoleColor[$highestRole[$authorID]]]
$footer[Pedido por $userTag;$authorAvatar]

$endif
`
})