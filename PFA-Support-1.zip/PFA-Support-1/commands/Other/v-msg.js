module.exports = ({
name: "verif-message",
aliases: ["v-msg", "v-message", "verif-msg"],
code: `
$color[009c24]
$title[Verification]
$description[To get verfied, type $getServerVar[prefix]verify, i will send you a code into your DM]

$onlyIf[$getServerVar[verif_role]!=0;Verification has not been setup!]

$onlyPerms[admin;{title:Missing Permissions}{description:You need the permission of: \`ADMINISTRATOR\` to use this command!}{color:$getRoleColor[$highestrole[$authorid]]}]
`
})