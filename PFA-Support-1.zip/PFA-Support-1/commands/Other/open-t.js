module.exports = ({
name: "ticket-open",
aliases: "t-open",
code: `$deletecommand

$onlyIf[$getServerVar[ticket_category]!=0;{title:Error}{description:You need to setup the tickets, to this, use $getServerVar[prefix]ticket-setup}{color:$getRoleColor[$highestRole[$authorID]]}]

$onlyIf[$getServerVar[ticket_lang]!=0;{title:Error}{description:You need to setup the tickets, to this, use $getServerVar[prefix]ticket-setup}{color:$getRoleColor[$highestRole[$authorID]]}]

$newTicket[ticket_$username;{title:Ticket}{description:$replaceText[$replaceText[$checkCondition[$getServerVar[ticket_lang]==ES];true;Hola $username!
*Gracias por crear un ticket!*

> __\`Por favor diganos todos sus problemas\`__

Si ningun staff le responde en 10 minutos, es libre de pingear a alguno :wink:

__Use $getServerVar[prefix]ticket-close para cerrar el ticket.__;-1];false;Hello $username!
*Thanks for creating a ticket!*

> __\`Please tell us all your problems\`__

If no staff responds to you within 10 minutes, you are free to ping one of them :wink:

__Use $getServerVar[prefix]ticket-close to close this ticket.__;-1]}{color:$getRoleColor[$highestRole[$authorID]]};$getServerVar[ticket_category]; no;Error!]
`
})