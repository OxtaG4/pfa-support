module.exports = ({
name: "add-wiki",
code: `$useChannel[$getServerVar[wiki_channel]]
$addTimestamp
$title[New Wiki!]
$description[$noMentionMessage]
$argsCheck[>1;Put a message!]
$onlyIf[$getServerVar[wiki_channel]!=0;Channel for the wikis has not been setted, set the channel using $getServerVar[prefix]set-wikichannel]
$color[$getRoleColor[$highestRole[$authorID]]]
$footer[$userTag;$authorAvatar]
`
})